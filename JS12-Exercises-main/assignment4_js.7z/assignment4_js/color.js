class Color {
    colors = {RED: 1, ORANGE: 2, YELLOW: 3, GREEN: 4, BLUE: 5 , INDIGO: 6, VIOLET: 7}
}

module.exports = Color

