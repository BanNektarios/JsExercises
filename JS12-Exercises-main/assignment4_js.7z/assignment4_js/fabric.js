class Fabric {
    fabrics = {WOOL: 3, COTTON: 5, POLYESTER: 6.5, RAYON: 9.2, LINEN: 13.6, CASHMERE: 17.4, SILK: 25.2}
}

module.exports = Fabric